import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:budget_planner/models/data/data.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

class OnboardingFlowScreen extends StatefulWidget {
  const OnboardingFlowScreen({super.key});

  @override
  State<OnboardingFlowScreen> createState() =>
      _OnboardingFlowScreenState();
}

class _OnboardingFlowScreenState
    extends State<OnboardingFlowScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  final int _totalSteps = 3; // Categories, Name, DOB
  final List<String> _selectedTitles = []; // For categories
  final TextEditingController _nameController =
      TextEditingController();
  DateTime _selectedDate = DateTime.now();

  @override
  void initState() {
    super.initState();
    // Rebuild UI when user types name (to enable Next button dynamically)
    _nameController.addListener(() {
      setState(() {});
    });
  }

  void _toggleCategory(String title) {
    setState(() {
      if (_selectedTitles.contains(title)) {
        _selectedTitles.remove(title);
      } else {
        if (_selectedTitles.length < 6) {
          _selectedTitles.add(title);
        }
      }
    });
  }

  bool _isSelected(String title) =>
      _selectedTitles.contains(title);

  void _nextPage() {
    if (_currentPage < _totalSteps - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    } else {
      context.push('/home'); // Go to home after last step
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 40),
            // Moving progress bar
            LinearProgressIndicator(
              value: (_currentPage + 1) / _totalSteps,
              backgroundColor: Colors.grey,
              color: Colors.black,
              minHeight: 4,
            ),
            Expanded(
              child: PageView(
                controller: _pageController,
                physics:
                    const NeverScrollableScrollPhysics(),
                onPageChanged: (index) {
                  setState(() => _currentPage = index);
                },
                children: [
                  _buildCategoryStep(),
                  _buildNameStep(),
                  _buildDobStep(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // STEP 1: Categories
  Widget _buildCategoryStep() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 20),
          const Text(
            'What do you likely spend on the most?',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Select up to 6 categories   ${_selectedTitles.length}/6',
            style: const TextStyle(
              color: Colors.grey,
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 20),
          Expanded(
            child: SingleChildScrollView(
              child: Wrap(
                spacing: 8,
                runSpacing: 12,
                children: AvailableIcons.map((category) {
                  final IconData icon = category['icon'];
                  final String title = category['name'];
                  final bool selected = _isSelected(title);

                  return GestureDetector(
                    onTap: () => _toggleCategory(title),
                    child: AnimatedContainer(
                      duration: const Duration(
                        milliseconds: 200,
                      ),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 10,
                      ),
                      decoration: BoxDecoration(
                        color: selected
                            ? Colors.black
                            : Colors.white,
                        borderRadius: BorderRadius.circular(
                          20,
                        ),
                        border: Border.all(
                          color: Colors.black.withOpacity(
                            0.3,
                          ),
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            icon,
                            color: selected
                                ? Colors.white
                                : Colors.black,
                            size: 16,
                          ),
                          const SizedBox(width: 6),
                          ConstrainedBox(
                            constraints:
                                const BoxConstraints(
                                  maxWidth: 100,
                                ),
                            child: Text(
                              title,
                              overflow:
                                  TextOverflow.ellipsis,
                              style: TextStyle(
                                color: selected
                                    ? Colors.white
                                    : Colors.black,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                          if (selected)
                            const Padding(
                              padding: EdgeInsets.only(
                                left: 6,
                              ),
                              child: Icon(
                                CupertinoIcons
                                    .clear_circled_solid,
                                color: Colors.white,
                                size: 18,
                              ),
                            ),
                        ],
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
          ),
          const SizedBox(height: 20),
          _buildNextButton(
            enabled: _selectedTitles.isNotEmpty,
          ),
        ],
      ),
    );
  }

  // STEP 2: Name
  Widget _buildNameStep() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // Centered content
          Expanded(
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    "WHAT'S YOUR NAME?",
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 20),
                  TextField(
                    controller: _nameController,
                    decoration: const InputDecoration(
                      hintText: "Enter your name",
                      border: OutlineInputBorder(),
                    ),
                  ),
                ],
              ),
            ),
          ),
          // Next button stays at bottom
          _buildNextButton(
            enabled: _nameController.text.trim().isNotEmpty,
          ),
        ],
      ),
    );
  }

  // STEP 3: Date of Birth
  Widget _buildDobStep() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // Centered content
          Expanded(
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    "WHEN WERE YOU BORN?",
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 20),
                  GestureDetector(
                    onTap: () async {
                      final DateTime? picked =
                          await showDatePicker(
                            context: context,
                            initialDate: _selectedDate,
                            firstDate: DateTime(1900),
                            lastDate: DateTime.now(),
                          );
                      if (picked != null) {
                        setState(
                          () => _selectedDate = picked,
                        );
                      }
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        vertical: 14,
                        horizontal: 12,
                      ),
                      decoration: BoxDecoration(
                        border: Border.all(
                          // color: Colors.green,
                        ),
                        borderRadius: BorderRadius.circular(
                          10,
                        ),
                      ),
                      child: Text(
                        DateFormat(
                          "MMMM d, yyyy",
                        ).format(_selectedDate),
                        style: const TextStyle(
                          fontSize: 18,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          // Finish button at bottom
          _buildNextButton(enabled: true),
        ],
      ),
    );
  }

  // Reusable Next button
  Widget _buildNextButton({required bool enabled}) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: enabled ? _nextPage : null,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.black,
          padding: const EdgeInsets.symmetric(vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: Text(
          _currentPage == _totalSteps - 1
              ? 'Finish'
              : 'Next',
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w600,
            fontSize: 16,
          ),
        ),
      ),
    );
  }
}

import 'package:budget_planner/app.dart';
import 'package:budget_planner/screens/home/home_screen.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}
